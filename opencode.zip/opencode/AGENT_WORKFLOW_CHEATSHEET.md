# Agent Workflow Cheatsheet

## 1. Bikin Bot Python / Node.js

Pakai ini kalau mau bikin bot Telegram, Discord, WhatsApp tooling, automation, atau service kecil.

### Kalau idenya belum jelas

Mulai dari planner:

```text
@prometheus bikin plan bot Telegram pake Python, fitur auto-reply whitelist user, config env, logging, dan run lokal
```

Lalu eksekusi:

```text
@atlas eksekusi plan Prometheus tadi sampai bisa run lokal dan ada README
```

### Kalau idenya sudah jelas

Langsung worker kuat:

```text
@hephaestus bikin bot Discord Node.js yang bisa command /ping, /ask ke OpenRouter, config .env, logging, dan cara run lokal
```

### Kalau bot sudah ada tapi error

```text
@bug-hunter bot ini error pas connect Telegram, cari root cause dan fix minimal
```

### Patokan stack

- Telegram / userbot / API automation: Python.
- Discord / dashboard / realtime web / Node ecosystem: Node.js.

## 2. Bikin Web

Pakai ini kalau mau bikin website, dashboard, admin panel, frontend app, atau web tool.

### Project web serius

Mulai dari planner:

```text
@prometheus rancang web dashboard Next.js untuk manage bot Telegram, ada login, list user whitelist, logs realtime, settings API key, run lokal dulu
```

Lalu eksekusi:

```text
@atlas eksekusi plan itu sampai bisa jalan lokal
```

Terakhir review:

```text
@code-quality review perubahan web ini, fokus bug, security, performance, dan missing tests
```

### Web cepat / prototype

```text
@hephaestus bikin web dashboard Next.js untuk manage bot Telegram, UI compact profesional, bisa run lokal, pakai .env, dan ada README
```

### Web existing error

```text
@bug-hunter web ini error pas build/run, cari root cause dan fix minimal
```

### Security check

```text
@security-audit audit web ini, fokus auth, token, upload, API private, dan session
```

## Shortcut Ingatan

- Belum jelas: `@prometheus` dulu.
- Sudah jelas dan mau langsung jadi: `@hephaestus`.
- Ada plan dan mau dieksekusi: `@atlas`.
- Error: `@bug-hunter`.
- Review sebelum ship: `@code-quality`.
- Security: `@security-audit`.
