---
description: Structured 7-phase feature development workflow. Explores codebase, asks clarifying questions, designs architecture with multiple options, implements, reviews, and summarizes.
argument-hint: "<feature description>"
---

Launch the 7-phase feature development workflow.

Feature request: $ARGUMENTS

## Phase 1: Discovery
- Understand the feature requirements fully.
- What problem does this solve? Who benefits?
- What are the acceptance criteria?
- Ask the user clarifying questions if the request is vague.

## Phase 2: Codebase Exploration
- Use @explore to map the relevant parts of the codebase.
- Trace execution paths related to this feature.
- Identify files that need to change.
- Find existing patterns to follow.
- Run 2-3 parallel explorations for speed.

## Phase 3: Clarifying Questions
- BLOCK here. Ask the user about any ambiguities BEFORE coding.
- Present specific options, not open-ended questions.
- Wait for answers before proceeding.

## Phase 4: Architecture Design
- Present 2-3 architecture options:

### Option A: Minimal (fastest)
- Changes, effort, trade-offs

### Option B: Clean (best architecture)
- Changes, effort, trade-offs

### Option C: Pragmatic (recommended)
- Changes, effort, trade-offs

- Let the user choose before implementing.

## Phase 5: Implementation
- Code with minimal, precise changes.
- Use a todo list to track progress.
- Follow existing code patterns found in Phase 2.
- Handle errors properly.

## Phase 6: Quality Review
- Run @code-quality on all changed files.
- Run @silent-failure-hunter on error handling code.
- Run @type-analyzer if TypeScript.
- Fix any 🔴 CRITICAL issues immediately.

## Phase 7: Summary
- Report what was done.
- List files changed.
- Note what to test manually.
- Flag any remaining concerns or follow-up tasks.
