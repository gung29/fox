---
description: Full git pipeline — commit, push, and create a PR in one step. Creates a branch if on main, generates commit message, pushes, and opens a PR with comprehensive description.
argument-hint: "[PR title or description]"
---

Full commit → push → PR pipeline.

## Steps

1. Run `git status` and `git branch --show-current` to check current state.
2. If on `main` or `master`:
   - Create a new branch with a descriptive name based on the changes.
   - `git checkout -b feature/descriptive-name`
3. Stage all changes (except `.env`, secrets, credentials).
4. Analyze `git log --oneline -10` for commit style.
5. Create commit with style-matched message.
6. Push to remote: `git push -u origin HEAD`.
7. Analyze ALL commits in the branch (not just latest) with `git log main..HEAD`.
8. Create PR using `gh pr create`:
   - Title: concise summary of all changes
   - Body: comprehensive description covering all commits
   - If user provided input: $ARGUMENTS — use as PR title/description hint.
9. Report the PR URL.
