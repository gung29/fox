---
description: Run code quality review + bug hunt on recent changes. Automatically invokes @code-quality and @bug-hunter subagents.
argument-hint: "[path or description of what to review]"
---

Run a full code review and bug hunt on the recent changes.

## Steps

1. First, use `git diff` to see what files were recently changed.
2. Then invoke **@code-quality** to review all changed files for:
   - Code quality issues
   - Security vulnerabilities  
   - Performance problems
   - Missing error handling
   - Type safety issues
3. After that, invoke **@bug-hunter** to search for:
   - Logic bugs
   - Race conditions
   - Edge cases
   - Null/undefined issues
4. Summarize all findings with severity levels and suggested fixes.

If a specific path or description is provided: $ARGUMENTS — focus the review on that area.
Otherwise, review all recent git changes.
