---
description: Auto-stage changes, analyze diffs, and create a commit with a style-matched message. Analyzes the last 10 commit messages to match the repo's convention.
argument-hint: "[optional commit message override]"
---

Create a git commit with an auto-generated message that matches the repo's style.

## Steps

1. Run `git status` to see all changes (staged + unstaged + untracked).
2. Run `git diff` to see what changed.
3. Run `git log --oneline -10` to analyze the repo's commit message style/convention.
4. Stage all relevant changes with `git add`. Do NOT stage `.env`, credentials, or secrets.
5. Generate a commit message that:
   - Matches the repo's existing commit style (conventional commits, imperative, etc.)
   - Explains **why** the change was made, not just what
   - Is concise (1-2 lines)
6. If the user provided a message override: $ARGUMENTS — use that instead.
7. Create the commit with `git commit -m "message"`.
8. Show the result with `git log --oneline -3`.
