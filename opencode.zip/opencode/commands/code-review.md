---
description: Run comprehensive code review with multiple parallel agents. Uses confidence scoring (0-100, threshold 80) to eliminate false positives. Reviews correctness, security, silent failures, and types.
argument-hint: "[file path, PR number, or 'all' for recent changes]"
---

Run a comprehensive multi-agent code review.

Target: $ARGUMENTS (default: recent git changes)

## Process

1. **Gather changes:**
   - If a file path is given, review that file.
   - If a PR number is given, run `gh pr diff <number>`.
   - Otherwise, run `git diff` for recent changes.

2. **Launch parallel reviews** (use @task for each):

   **Agent 1: @code-quality**
   - Correctness, bugs, logic errors
   - Confidence scoring 0-100, only report >= 80

   **Agent 2: @silent-failure-hunter**
   - Empty catches, swallowed errors, fire-and-forget
   - Focus on error handling patterns

   **Agent 3: @type-analyzer** (if TypeScript)
   - Type safety across 4 dimensions
   - any-casts, missing null checks, leaky abstractions

   **Agent 4: @security-audit**
   - Injection, auth bypass, secrets, OWASP top 10

3. **Aggregate results:**
   - Combine all findings
   - Deduplicate overlapping issues
   - Sort by severity (🔴 > 🟠 > 🟡 > 🔵)

4. **Report:**
   - Total issues by severity
   - Overall score (1-10)
   - Top 3 priorities to fix
   - Verdict: "Ship it! ✅" or "Needs work ⚠️"
