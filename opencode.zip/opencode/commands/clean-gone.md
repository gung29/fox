---
description: Remove local branches that have been deleted from the remote. Cleans up stale branches after PRs are merged.
---

Clean up local branches deleted from remote.

## Steps

1. Fetch latest remote state: `git fetch --prune`.
2. List branches where remote is gone: `git branch -vv | grep ': gone]'`.
3. For each gone branch, delete it: `git branch -d <branch>`.
4. If delete fails (unmerged), warn the user and skip.
5. Report what was cleaned up.
