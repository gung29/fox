---
description: Automatically find and fix bugs in the codebase. Invokes @bug-hunter to investigate and apply fixes.
argument-hint: "[error message or bug description]"
---

Find and fix bugs in the codebase.

## Steps

1. If an error or bug description is provided: $ARGUMENTS — investigate that specific issue.
2. Otherwise, run `git diff` and check recent changes for potential bugs.
3. Invoke **@bug-hunter** to:
   - Identify the root cause
   - Apply the minimal fix
   - Verify the fix works (run build/tests if available)
   - Check for similar bugs elsewhere
4. Report what was found and fixed.
