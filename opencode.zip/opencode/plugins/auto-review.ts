import type { Plugin } from "@opencode-ai/plugin"

/**
 * Auto-Review Pipeline — FULLY AUTONOMOUS + PARALLEL
 *
 * After agent finishes significant work (session.idle):
 * 1. Detects what kind of files were edited
 * 2. Sends ONE prompt that instructs agent to launch
 *    MULTIPLE parallel subagent reviews via task tool
 * 3. Agent runs all reviews simultaneously, not sequentially
 *
 * This is faster because:
 * - TypeCheck + Code Quality + Security + Silent Failures + Types
 *   all run as parallel task() calls in a single message
 * - Instead of 5 sequential steps, it's 1 parallel batch
 */

const editedFiles = new Set<string>()
let editCount = 0
let reviewTriggered = false
let hasTypeScriptEdits = false
let hasSecurityRelevantEdits = false
let hasErrorHandlingEdits = false
let hasTypeDefinitionEdits = false

const REVIEW_THRESHOLD = 3

const SECURITY_PATTERNS = [
  "/api/", "auth", "login", "session", "token", "password",
  "middleware", "permission", "credential", "secret", "cookie",
]

const ERROR_PATTERNS = ["catch", "error", "exception", "try", "throw"]

const TYPE_PATTERNS = ["types.ts", "types/", ".d.ts", "interface", "schema"]

function matchesAny(str: string, patterns: string[]): boolean {
  const lower = str.toLowerCase()
  return patterns.some((p) => lower.includes(p))
}

export const AutoReviewPlugin: Plugin = async ({ client, directory }) => {
  return {
    "tool.execute.after": async (input, output) => {
      const tool = input.tool
      if (tool !== "edit" && tool !== "write" && tool !== "apply_patch") return

      const filePath: string = output.args?.filePath || ""
      if (!filePath || filePath.includes("node_modules") || filePath.includes(".git")) return

      editedFiles.add(filePath)
      editCount++
      reviewTriggered = false

      if (filePath.endsWith(".ts") || filePath.endsWith(".tsx")) hasTypeScriptEdits = true
      if (matchesAny(filePath, SECURITY_PATTERNS)) hasSecurityRelevantEdits = true
      if (matchesAny(filePath, TYPE_PATTERNS)) hasTypeDefinitionEdits = true

      if (tool === "edit") {
        const content: string = output.args?.newString || ""
        if (matchesAny(content, ERROR_PATTERNS)) hasErrorHandlingEdits = true
      }
    },

    "session.idle": async (input) => {
      if (reviewTriggered || editCount === 0) return

      const files = Array.from(editedFiles).slice(0, 20)
      const fileCount = editedFiles.size
      const edits = editCount
      const isTS = hasTypeScriptEdits
      const isSecurity = hasSecurityRelevantEdits
      const isErrorHandling = hasErrorHandlingEdits
      const isTypeChanges = hasTypeDefinitionEdits
      const meetsThreshold = edits >= REVIEW_THRESHOLD

      // Nothing to review
      if (!meetsThreshold && !isTS) return

      reviewTriggered = true

      // Reset state
      editCount = 0
      editedFiles.clear()
      hasTypeScriptEdits = false
      hasSecurityRelevantEdits = false
      hasErrorHandlingEdits = false
      hasTypeDefinitionEdits = false

      // Build parallel task instructions
      const fileList = files.join("\n- ")
      const parallelTasks: string[] = []

      if (isTS) {
        parallelTasks.push(
          `**Task 1: TypeCheck** — Run \`npx tsc --noEmit\` and report errors.`
        )
      }

      if (meetsThreshold) {
        parallelTasks.push(
          `**Task ${parallelTasks.length + 1}: Code Quality** — Use the task tool with subagent "code-quality" to review these files. Confidence scoring 0-100, only report >= 80. Score 1-10.`
        )
      }

      if (isSecurity) {
        parallelTasks.push(
          `**Task ${parallelTasks.length + 1}: Security Audit** — Use the task tool with subagent "general" to audit for: missing auth, input validation, secrets exposure, injection. Reference CWE/OWASP.`
        )
      }

      if (isErrorHandling) {
        parallelTasks.push(
          `**Task ${parallelTasks.length + 1}: Silent Failures** — Use the task tool with subagent "general" to hunt: empty catches, swallowed errors, missing .catch(), fire-and-forget async.`
        )
      }

      if (isTypeChanges) {
        parallelTasks.push(
          `**Task ${parallelTasks.length + 1}: Type Safety** — Use the task tool with subagent "general" to check: any-casts, unsafe assertions, missing null checks, leaky abstractions. Score Safety/Encapsulation/Invariants/Usefulness 1-10.`
        )
      }

      const prompt = [
        `🔍 **Auto-Review Pipeline** — ${edits} edits across ${fileCount} files.`,
        ``,
        `Files changed:`,
        `- ${fileList}`,
        ``,
        `## IMPORTANT: Run these reviews IN PARALLEL`,
        `Launch ALL of the following as simultaneous task() calls in a SINGLE message.`,
        `Do NOT run them sequentially — call multiple task tools at once.`,
        ``,
        ...parallelTasks,
        ``,
        `---`,
        `After all tasks complete, aggregate results:`,
        `- Combine findings, deduplicate, sort by severity (🔴 > 🟡 > 🔵)`,
        `- Overall score 1-10`,
        `- If 🔴 CRITICAL found → fix immediately`,
        `- If all good → "Ship it! ✅"`,
      ].join("\n")

      try {
        await client.session.prompt({
          path: { id: input.sessionID },
          body: { parts: [{ type: "text", text: prompt }] },
        })
      } catch (err) {
        await client.app.log({
          body: {
            service: "auto-review",
            level: "warn",
            message: `Auto-review failed: ${err instanceof Error ? err.message : "unknown"}`,
          },
        })
      }
    },

    "session.created": async () => {
      await client.app.log({
        body: {
          service: "auto-review",
          level: "info",
          message: `Auto-review pipeline active (PARALLEL mode) in ${directory}. Threshold: ${REVIEW_THRESHOLD}+ edits.`,
        },
      })
    },

    "file.edited": async (input) => {
      const fp = (input as { filePath?: string }).filePath
      if (fp) {
        editedFiles.add(fp)
        if (fp.endsWith(".ts") || fp.endsWith(".tsx")) hasTypeScriptEdits = true
        if (matchesAny(fp, SECURITY_PATTERNS)) hasSecurityRelevantEdits = true
        reviewTriggered = false
      }
    },
  }
}
