import type { Plugin } from "@opencode-ai/plugin"

/**
 * Auto-Skill Loader Plugin — FULLY AUTONOMOUS
 *
 * When agent edits frontend files (.tsx, .jsx, .css, etc),
 * sends a prompt to the session telling the agent to load
 * the frontend-design skill. Uses client.session.prompt()
 * with noReply to inject context without triggering a response.
 */

const SKILL_MAP: Record<string, string> = {
  ".tsx": "frontend-design",
  ".jsx": "frontend-design",
  ".css": "frontend-design",
  ".scss": "frontend-design",
  ".html": "frontend-design",
  ".vue": "frontend-design",
  ".svelte": "frontend-design",
}

const loadedSkills = new Set<string>()

export const AutoSkillPlugin: Plugin = async ({ client }) => {
  return {
    "tool.execute.after": async (input, output) => {
      if (input.tool !== "edit" && input.tool !== "write") return

      const filePath: string = output.args?.filePath || ""
      if (!filePath) return

      for (const [ext, skillName] of Object.entries(SKILL_MAP)) {
        if (filePath.endsWith(ext) && !loadedSkills.has(skillName)) {
          loadedSkills.add(skillName)

          try {
            // Inject context telling agent to load the skill
            // noReply: true means it adds context without triggering AI response
            await client.session.prompt({
              path: { id: (input as { sessionID?: string }).sessionID || "" },
              body: {
                noReply: true,
                parts: [{
                  type: "text",
                  text: `🎨 Auto-detected frontend file (${ext}). Load the "frontend-design" skill for better UI/design quality. Use: skill({ name: "frontend-design" })`,
                }],
              },
            })
          } catch {
            // Session ID might not be available in tool events — fallback to log
            await client.app.log({
              body: {
                service: "auto-skill",
                level: "info",
                message: `Frontend file detected (${ext}). Agent should load skill: ${skillName}`,
              },
            })
          }
          break
        }
      }
    },
  }
}
