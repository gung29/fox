import type { Plugin } from "@opencode-ai/plugin"

/**
 * Explanatory Output Style Plugin
 * 
 * Injects educational context at session start.
 * Encourages the agent to provide insights about
 * implementation choices and codebase patterns.
 * 
 * Based on Anthropic's explanatory-output-style plugin.
 */

export const ExplanatoryStylePlugin: Plugin = async ({ client }) => {
  return {
    "session.created": async (input, output) => {
      await client.app.log({
        body: {
          service: "explanatory-style",
          level: "info",
          message: "Explanatory mode active — agent will provide educational insights.",
        }
      })
    },

    // Inject context into compaction so insights persist
    "experimental.session.compacting": async (input, output) => {
      output.context.push(`## Explanatory Mode
When making implementation choices, occasionally provide brief educational insights:
- Why a particular pattern was chosen over alternatives
- What trade-offs were considered
- Interesting codebase patterns worth noting
Format insights as: ★ Insight: [brief explanation]
Keep insights concise (1-2 sentences). Don't force them — only when genuinely useful.`)
    },
  }
}
