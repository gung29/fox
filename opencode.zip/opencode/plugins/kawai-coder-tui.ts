  import type { TuiPlugin } from "@opencode-ai/plugin/tui"
import type { Plugin } from "@opencode-ai/plugin"

type OpenTuiSolid = typeof import("@opentui/solid")

function text(solid: OpenTuiSolid, value: string, fg: string, attributes?: number) {
  const { createElement, insert, spread } = solid
  const node = createElement("text")
  spread(node, { fg, attributes }, false)
  insert(node, value)
  return node
}

function logo(solid: OpenTuiSolid) {
  const { createElement, insert, spread } = solid
  const root = createElement("box")
  spread(root, {
    flexDirection: "column",
    alignItems: "center",
    paddingBottom: 1,
  }, false)

  insert(root, [
    text(solid, "Kawai Coder", "#f472b6", 1),
    text(solid, "local-first AI coding workspace", "#94a3b8"),
  ])

  return root
}

export const server: Plugin = async () => ({})

export const tui: TuiPlugin = async (api) => {
  if (!api?.slots) return {} as never

  const solid = await import("@opentui/solid")

  api.slots.register({
    slots: {
      home_logo: () => logo(solid),
    },
  })
}
