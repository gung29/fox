import type { Plugin } from "@opencode-ai/plugin"

/**
 * Security Guard Plugin
 * 
 * Autonomous security protections:
 * 1. Block reading .env files
 * 2. Warn on writing files with potential secrets
 * 3. Block dangerous bash commands
 */

const BLOCKED_READ_PATTERNS = [
  ".env",
  ".env.local",
  ".env.production",
  "credentials.json",
  "serviceAccountKey.json",
  "id_rsa",
  "id_ed25519",
]

const DANGEROUS_BASH_PATTERNS = [
  /rm\s+-rf\s+\/(?!tmp)/,          // rm -rf / (not /tmp)
  /git\s+push\s+.*--force\s+.*main/,  // force push to main
  /git\s+push\s+.*--force\s+.*master/, // force push to master
  /chmod\s+777/,                    // world-writable
  /curl.*\|\s*(?:bash|sh)/,        // pipe curl to shell
]

export const SecurityGuardPlugin: Plugin = async ({ client }) => {
  return {
    "tool.execute.before": async (input, output) => {
      // Block reading sensitive files
      if (input.tool === "read") {
        const filePath: string = output.args?.filePath || ""
        for (const pattern of BLOCKED_READ_PATTERNS) {
          if (filePath.includes(pattern)) {
            await client.app.log({
              body: {
                service: "security-guard",
                level: "warn",
                message: `Blocked read of sensitive file: ${filePath}`,
              }
            })
            throw new Error(`🛡️ Security Guard: Reading "${pattern}" files is blocked. These may contain secrets.`)
          }
        }
      }

      // Warn on dangerous bash commands
      if (input.tool === "bash") {
        const command: string = output.args?.command || ""
        for (const pattern of DANGEROUS_BASH_PATTERNS) {
          if (pattern.test(command)) {
            await client.app.log({
              body: {
                service: "security-guard",
                level: "warn",
                message: `Blocked dangerous command: ${command.slice(0, 100)}`,
              }
            })
            throw new Error(`🛡️ Security Guard: Dangerous command blocked — "${command.slice(0, 80)}..."`)
          }
        }
      }

      // Warn when writing files that might contain secrets
      if (input.tool === "write" || input.tool === "edit") {
        const content: string = output.args?.content || output.args?.newString || ""
        const secretPatterns = [
          /(?:api[_-]?key|apikey)\s*[:=]\s*["'][^"']{20,}/i,
          /(?:secret|password|token)\s*[:=]\s*["'][^"']{8,}/i,
          /(?:AKIA|ASIA)[A-Z0-9]{16}/,  // AWS access key
          /ghp_[a-zA-Z0-9]{36}/,         // GitHub token
          /sk-[a-zA-Z0-9]{32,}/,         // OpenAI key
        ]

        for (const pattern of secretPatterns) {
          if (pattern.test(content)) {
            await client.app.log({
              body: {
                service: "security-guard",
                level: "warn",
                message: `Potential secret detected in file write!`,
              }
            })
            // Don't block, just warn — the agent should handle it
            break
          }
        }
      }
    },
  }
}
